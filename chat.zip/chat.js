new Vue({
    el: '#app',
    data: {
        username: document.getElementById('username').value,
        avatar: document.getElementById('avatar').value,
        messages: [],
        newMessage: '',
        autoScroll: true
    },
    methods: {
        fetchMessages() {
            $.get("load_messages.php", data => {
                this.messages = data ? JSON.parse(data) : [];
                if (this.autoScroll) {
                    this.scrollToBottom();
                }
            });
        },
        sendMessage() {
            if (this.newMessage.trim()) {
                const message = {
                    username: this.username,
                    avatar: this.avatar,
                    text: this.newMessage.trim()
                };
                this.messages.push(message);
                this.newMessage = '';
                $.post("save_message.php", JSON.stringify(message));
            }
        },
        uploadImage() {
            this.$refs.imageInput.click();
        },
        handleImageUpload(event) {
            const file = event.target.files[0];
            if (file) {
                const formData = new FormData();
                formData.append("file", file);
                formData.append("type", "image");

                $.ajax({
                    url: 'upload_file.php',
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: (response) => {
                        const { compressed, original } = JSON.parse(response);
                        this.sendMediaMessage(compressed, 'image', original);
                    }
                });
            }
        },
        uploadVideo() {
            this.$refs.videoInput.click();
        },
        handleVideoUpload(event) {
            const file = event.target.files[0];
            if (file) {
                const formData = new FormData();
                formData.append("file", file);
                formData.append("type", "video");

                $.ajax({
                    url: 'upload_file.php',
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: (response) => {
                        const { compressed, original } = JSON.parse(response);
                        this.sendMediaMessage(compressed, 'video', original);
                    }
                });
            }
        },
        sendMediaMessage(fileUrl, mediaType, originalUrl) {
            const message = {
                username: this.username,
                avatar: this.avatar,
                text: fileUrl,
                original: originalUrl,
                isMedia: true,
                isImage: mediaType === 'image',
                isVideo: mediaType === 'video'
            };
            this.messages.push(message);
            $.post("save_message.php", JSON.stringify(message));
        },
        scrollToBottom() {
            this.$nextTick(() => {
                setTimeout(() => {
                    const messagesContainer = this.$refs.messages;
                    messagesContainer.scrollTop = messagesContainer.scrollHeight;
                }, 200);
            });
        },
        checkIfScrolledToBottom() {
            const messagesContainer = this.$refs.messages;
            const isAtBottom = messagesContainer.scrollTop + messagesContainer.clientHeight >= messagesContainer.scrollHeight - 10;
            this.autoScroll = isAtBottom;
        },
        // 格式化消息显示
        formatMessage(message) {
            if (message.isMedia) {
                if (message.isImage) {
                    return `<a href="${message.original}" target="_blank" class="media-link">
                              <img src="As.png" alt="图片" class="media-thumbnail">
                            </a>`;
                } else if (message.isVideo) {
                    return `<a href="${message.original}" target="_blank" class="media-link">
                              <img src="Ad.png" alt="视频" class="media-thumbnail">
                            </a>`;
                }
            }
            // 普通文本消息直接返回
            return message.text;
        }
    },
    mounted() {
        this.fetchMessages();
        setInterval(this.fetchMessages, 1000);
    }
});