<?php
if (file_exists('uploads/mes.json')) {
    echo file_get_contents('uploads/mes.json');
} else {
    echo '[]';
}
?>