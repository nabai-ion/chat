<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = file_get_contents('php://input');
    $message = json_decode($data, true);

    $messages = [];
    if (file_exists('uploads/mes.json')) {
        $messages = json_decode(file_get_contents('uploads/mes.json'), true);
    }

    $messages[] = $message;
    file_put_contents('uploads/mes.json', json_encode($messages));
}
?>