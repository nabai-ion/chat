<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['file'])) {
        $file = $_FILES['file'];
        $type = $_POST['type']; // 'image' 或 'video'

        $uploadDir = 'uploads/movcs/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $originalPath = $uploadDir . basename($file['name']);
        move_uploaded_file($file['tmp_name'], $originalPath);

        if ($type === 'image') {
            // 已移除压缩功能，直接使用原路径
            echo json_encode([
                'compressed' => $originalPath,
                'original' => $originalPath
            ]);
        } else {
            echo json_encode([
                'compressed' => $originalPath,
                'original' => $originalPath
            ]);
        }
    }
}
?>