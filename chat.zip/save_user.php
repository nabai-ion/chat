<?php
session_start();

function isUsernameTaken($username) {
    $file = 'uploads/user.txt';
    if (file_exists($file)) {
        $users = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        return in_array($username, $users);
    }
    return false;
}

function saveUsername($username) {
    $file = 'uploads/user.txt';
    file_put_contents($file, $username . PHP_EOL, FILE_APPEND);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $username = htmlspecialchars($_POST['username']);
    
    if (isUsernameTaken($username)) {
        echo json_encode(['success' => false, 'message' => '用户名已存在，请选择其他用户名']);
        exit();
    }

    // 默认头像路径
    $defaultAvatar = 'ions/default-avatar.png';

    // 如果用户上传了头像
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] == UPLOAD_ERR_OK) {
        $avatar = $_FILES['avatar'];
        $uploadDir = 'uploads/avatars/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $avatarName = uniqid() . "_" . basename($avatar['name']);
        $avatarPath = $uploadDir . $avatarName;
        
        if (move_uploaded_file($avatar['tmp_name'], $avatarPath)) {
            // 使用上传的头像
        } else {
            echo json_encode(['success' => false, 'message' => '头像上传失败']);
            exit();
        }
    } else {
        // 没有上传头像，使用默认头像
        $avatarPath = $defaultAvatar;
    }

    // 保存用户信息
    $_SESSION['username'] = $username;
    $_SESSION['avatar'] = $avatarPath;
    saveUsername($username);
    
    // 设置长期有效的Cookie（100年）
    $cookieData = json_encode([
        'username' => $username,
        'avatar' => $avatarPath
    ]);
    
    setcookie(
        'user_data', 
        $cookieData,
        time() + (100 * 365 * 24 * 60 * 60), // 100年有效期
        '/',
        '',
        false,
        true // HttpOnly标志
    );

    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => '无效的请求']);
}
?>