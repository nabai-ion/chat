function login() {
    const username = document.getElementById('username').value;
    const avatarInput = document.getElementById('avatarInput');
    
    if (username) { // 只需要用户名，头像可选
        const formData = new FormData();
        formData.append('username', username);
        // 如果用户选择了头像文件，则添加；否则不添加，由服务器端使用默认头像
        if (avatarInput.files[0]) {
            formData.append('avatar', avatarInput.files[0]);
        }

        fetch('save_user.php', {
            method: 'POST',
            body: formData
        }).then(response => response.json())
          .then(data => {
              if (data.success) {
                  window.location.href = 'chat.php';
              } else {
                  alert(data.message);
              }
          });
    } else {
        alert('请输入用户名');
    }
}
