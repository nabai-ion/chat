<?php
session_start();

// 优先使用session中的登录信息
if (isset($_SESSION['username']) && isset($_SESSION['avatar'])) {
    $username = $_SESSION['username'];
    $avatar = $_SESSION['avatar'];
} 
// 如果session不存在，但cookie存在，则从cookie恢复登录状态
elseif (isset($_COOKIE['user_data'])) {
    $userData = json_decode($_COOKIE['user_data'], true);
    
    if ($userData && isset($userData['username']) && isset($userData['avatar'])) {
        $_SESSION['username'] = $userData['username'];
        $_SESSION['avatar'] = $userData['avatar'];
        
        $username = $userData['username'];
        $avatar = $userData['avatar'];
    } else {
        // Cookie数据无效，重定向到登录页
        header("Location: index.php");
        exit();
    }
} else {
    // 既无session也无cookie，重定向到登录页
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>微聊</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <input type="hidden" id="username" value="<?php echo htmlspecialchars($username); ?>">
    <input type="hidden" id="avatar" value="<?php echo htmlspecialchars($avatar); ?>">

    <div id="app">
        <div class="chat-container">
            <div class="header">
                <h2>微聊</h2>
                <span>你好 <?php echo htmlspecialchars($username); ?>!</span>
                <img src="<?php echo htmlspecialchars($avatar); ?>" class="avatar" alt="头像">
            </div>
            
            <!-- 上传按钮 -->
            <div class="upload-buttons">
                <button @click="uploadImage">上传图片</button>
                <input type="file" ref="imageInput" style="display: none;" @change="handleImageUpload" accept="image/*">
                
                <button @click="uploadVideo">上传视频</button>
                <input type="file" ref="videoInput" style="display: none;" @change="handleVideoUpload" accept="video/*">
            </div>
            
            <!-- 消息区域 -->
            <div class="messages" ref="messages" @scroll="checkIfScrolledToBottom">
                <div v-for="(message, index) in messages" :key="index" class="message" :class="{'self': message.username === username}">
                    <img :src="message.avatar" class="avatar">
                    <div class="message-content">
                        <strong>{{ message.username }}:</strong>
                        <span v-if="!message.isMedia">{{ message.text }}</span>
                        
                        <!-- 图片消息显示 As.png 图标 -->
                        <a v-if="message.isImage" :href="message.original" target="_blank" class="media-link">
                            <img src="ions/As.png" class="media-thumbnail">
                        </a>
                        
                        <!-- 视频消息显示 Ad.png 图标 -->
                        <a v-if="message.isVideo" :href="message.original" target="_blank" class="media-link">
                            <img src="ions/Ad.png" class="media-thumbnail">
                        </a>
                    </div>
                </div>
            </div>

            <!-- 输入框区域 -->
            <div class="input-container">
                <input type="text" v-model="newMessage" @keyup.enter="sendMessage" placeholder="输入消息..." class="input-field">
                <button @click="sendMessage" class="btn">发送</button>
            </div>
        </div>
    </div>

    <!-- 引入Vue和jQuery -->
    <script src="JavaScript/vue-2.6.14-min.js"></script>
    <script src="JavaScript/jquery-3.6.0.min.js"></script>
    <!-- 引入外部JavaScript文件 -->
    <script src="chat.js"></script>
</body>
</html>